# Sec 2 Social Studies — EOY Revision Guide (Singapore MOE Syllabus)

---

## 0. HOW SOCIAL STUDIES IS MARKED

Same SBQ (Source-Based Question) skill family as History — you'll get sources (text, cartoons, statistics, photos) and be asked to interpret them, plus there's usually an extended/structured response question requiring a more developed written argument using both source evidence AND your own knowledge.

**Key question types:**
- **Comprehension** — what does the source say/show (lowest-level, just extract info)
- **Application/Explain** — use the source + background knowledge to explain a concept
- **Evaluate / To what extent do you agree...** — requires a BALANCED answer: points supporting the statement, points against, then a reasoned judgement. This is the highest-mark question type and the one students underperform on most, because they only argue one side.

**Golden rule for "to what extent" / evaluate questions:** you MUST show both sides of the argument even if you personally lean one way, then conclude with a justified stance. A one-sided answer is capped regardless of how well-argued it is.

---

## 1. KEY CONTENT THEMES (Lower Sec Social Studies)

### 1.1 Singapore's Diversity & Social Cohesion
- Singapore's multiracial, multireligious make-up
- Why managing diversity matters — potential for tension vs benefits of diversity
- Policies/approaches: e.g. common spaces, shared national identity, secularism (state neutral on religion), meritocracy

**Common exam angle:** "Explain why the government intervenes in managing racial/religious harmony" — expect answers about preventing conflict, ensuring fair treatment, and maintaining social stability, using real Singapore examples if given in the source.

### 1.2 Being Part of Singapore's Story (Nation-building / History-SS overlap)
- Challenges Singapore faced post-independence (economic survival, defence, housing, unemployment)
- How these challenges were addressed
- This overlaps with History content on independence — use whichever facts apply, the skill (SBQ) is what's actually being tested

### 1.3 Being Informed / Media Literacy (may or may not be in your school's Sec 2 scope)
- How to evaluate the reliability of information sources (similar reliability skills as History)
- Understanding bias, misinformation

---

## 2. HOW TO STRUCTURE A STRONG "EVALUATE / TO WHAT EXTENT" ANSWER

1. **Brief intro** stating you will consider both sides
2. **Points FOR** the statement — each point needs: a claim + explanation + evidence (from source or own knowledge)
3. **Points AGAINST** the statement — same structure
4. **Conclusion** — a clear, justified stance (doesn't have to be perfectly balanced 50/50 — you can argue one side is stronger, but you must show you considered both)

**Common mistake:** students write a conclusion that just repeats "there are both good and bad points" without actually taking a reasoned position — examiners want you to commit to a judgement, not sit on the fence vaguely.

---

## SELF-CHECK

1. What's the difference between a "comprehension" SBQ and an "evaluate/to what extent" question in terms of how you should answer?
2. Name two challenges Singapore faced after independence.
3. Why does structuring an "evaluate" answer with both sides matter, even if you already have a strong opinion?

*If you have an actual SS source-based question from your school, send it — I'll mark your attempt against how SBQ answers are actually scored.*
